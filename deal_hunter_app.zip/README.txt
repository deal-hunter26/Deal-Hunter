Deal Hunter App

Upload these files to your GitHub repository, then Vercel will deploy automatically.